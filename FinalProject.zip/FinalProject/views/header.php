<!DOCTYPE html>
<html lang="en">
<head>
  <title> Final Project </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="assets/bootstrap.min.css">
   <link rel="stylesheet" href="assets/bootstrap.js">
  <link rel="stylesheet" href="assets/custom.css">
  <link rel="stylesheet" href="assets/jquery-1.11.1.js">
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
</head>
<body>
<div>
<nav style="background:#383300; "class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#"> IS218 Project #4: Final Project </a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
	   <?php if(empty($userses)){ ?>
		<li><a href=""><button class="btn btn-sm btn-warning" > When you Register and Login, you will get to view, post, edit, and delete your questions </button></a></li> 
	   <?php } if(!empty($userses)){ ?>
	   <li><a href="index.php?action=display_new_question"><button class="btn btn-sm btn-success" > << Dashboard | </button></a></li>
         <li><a href="index.php?action=create_new_question"><button class="btn btn-sm btn-primary" > Post a new Question </button></a></li>
		 <li><a href="logout.php"><button class="btn btn-sm btn-danger" > Sign out </button></a></li>
	<?php } ?>
      </ul>
    </div>
  </div>
</nav>
</div>