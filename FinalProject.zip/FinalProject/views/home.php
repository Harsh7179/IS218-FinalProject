   <div style="padding-top:50px;" class="container">
      <div style=" background: #grey;"class="col-md-12 mx-auto text-center">
         <div class="header-title">
            <h1 class="wv-heading--title">
               Login to Your Account or Register
            </h1>
            <h2 class="wv-heading--subtitle">
               Get to post your Question and also view you previously posted questions
			   <img src="images/login-img.png" width="80" height="60"alt="Login">
			  <div> <a href="register.php"><button class="btn btn-md btn-warning" > Click here to Register </button></a></div> <br>
			  <div> <a href="index.php?action=display_login"><button class="btn btn-md btn-primary" > Click here to Login </button></a></div> 
            </h2>
         </div>
      </div>
   </div>