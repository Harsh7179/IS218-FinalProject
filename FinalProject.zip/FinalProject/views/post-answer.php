  <div class="col-md-3">
	<div class="single">
	  <h2> <br>  Post an Answer to this Question </h2>
	<?php
		 if($viewq['ownerid'] == $userses){
		?>
			 <p class="alert alert-danger" > Sorry! </br> You cannot post an answer to your own questions! </p>
   <?php  }else{  ?>
        <form action="" method="post" name="squestion">
		 <input type="hidden" name="action" value="post_answer">
	   <div class="single">
		  <div class="form-group">
			   <label class="left"> Type Your Answer </label>
			   <textarea class="form-control" name="answer" rows="4" cols="50" id="exampleFormControlTextarea1" rows="3" required ></textarea>
		  </div>
		  <div class="text-center ">
			 <button type="submit" name="submita" class="btn btn-block btn-warning"> Answer the Question Now </button>
		  </div>
	 </div>
	</form>
        <?php 
		     }
	   ?>
</div>
</div>