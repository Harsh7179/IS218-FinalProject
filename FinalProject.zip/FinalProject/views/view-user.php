  <div class="container">
    <div class="col-md-12">
	<h2 class="wv-heading--subtitle">
		<?php 
		     $newuser= new userData();
		    $user=userData::get_user($userses);  
		 ?> 
			<h3>  Welcome: <b style="color:green;"> <u> <?php echo $user['fname']; ?> <?php echo $user['lname']; ?> </u> <i> </i></b> Email:  <?php echo $user['email']; ?></h3> 
	 </div>
  </div> 