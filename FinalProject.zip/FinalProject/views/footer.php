       <br>
     <footer style="background:#48A5FF;">
  <br>
<div class="container">
<div class="row text-center">
    <div class="col-lg-12 col-md-12 col-sm-12">
		&copy; 2020 Projects Copyright. All Rights Reserved.  | by <a href="" target="_blank"> IS218 Project #3: MVC Pattern - Harsh </a> 
	 </div>
    </div>
</div>
<br>
</footer>
</body>
</html>