<?php 
class userData{
	
   public $email, $fname, $lname, $bd, $pass;
	
	public function getEmail(){
        return $this->email;
      }

    public function setEmail($email){
        $this->email = $email;
    }

    public function getFname(){
        return $this->fname;
    }

    public function setFname($fname){
        $this->fname = $fname;
    }
	
    public function getLname(){
        return $this->lname;
    }

    public function setLname($lname){
        $this->lname = $lname;
    }
	
	public function getBirthday(){
        return $this->birthday;
    }

    public function setBirthday($bd){
        $this->birthday = $bd;
    } 
	
	public function getPassword(){
        return $this->password;
    }

    public function setPassword($pass) {
        $this->password = $pass;
    }
	  
   public static function reg_user($email, $fname, $lname, $bd, $pass){  
	    $conn = Database::DB_con();
		$reg = $conn->prepare("INSERT INTO accounts(email,fname,lname,birthday, password)VALUES(:e, :f, :l, :b, :p)");
		$reg->bindparam(":e",$email);
		$reg->bindparam(":f",$fname);
		$reg->bindparam(":l",$lname);
		$reg->bindparam(":b",$bd);
		$reg->bindparam(":p",$pass);
		$reg->execute();
	       return $reg;				
}

 public static function check_user($email,$pass) {
      $dbconn=Database::DB_con();
       $stmt =$dbconn->prepare("SELECT * FROM accounts WHERE email='$email' ");
       $stmt->execute();
	   $user=$stmt->fetch(PDO::FETCH_ASSOC);
	   $up= $user['password'];
	   $uid = $user['id'];
	    /*-------------------------------------------------------------
    	Comparing the two passwords values and Creating session.
    -------------------------------------------------------------*/
		   if($pass == $up){
		      $_SESSION['userid'] = $uid;
		       // store user session
		       $userses=$_SESSION['userid'];
		    return true;
	}
}
			  		  
 public static function get_user($userses) {
      $dbconn=Database::DB_con();
    $query = 'SELECT * FROM accounts WHERE id= :u_id';
    $statement = $dbconn->prepare($query);
    $statement->bindValue(":u_id", $userses);
    $statement->execute();
    $user = $statement->fetch();
    $statement->closeCursor();
     return $user;
   }
}
$newuser= new userData();

?>