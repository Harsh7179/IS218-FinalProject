<?php
	    /*-------------------------------------------------------------
    	Question Class begins here
    -------------------------------------------------------------*/
class questionData{
	public $e;
	public $d;
	public $title;
	public $body;
	public $skills;
	
	public function getUEmail(){
        return $this->uemail;
      }

    public function setUemail($e){
        $this->uemail = $e;
    }

    public function getDate(){
        return $this->date;
    }

    public function setDate($d){
        $this->date = $d;
    }
	
	public function getTitle(){
        return $this->title;
    }

    public function setTitle($title){
        $this->title = $title;
    } 	
	
    public function getBody(){
        return $this->body;
    }

    public function setBody($body){
        $this->body = $body;
    }
	
	public function getSkills(){
        return $this->skills;
    }

    public function setSkills($skills) {
        $this->Skills = $skills;
    }
	
public static function create_new_question($e,$userses,$d,$title,$body,$skills){
	 $conn = Database::DB_con();			
		$add = $conn->prepare("INSERT INTO questions(owneremail, ownerid, createddate, title, body, skills)VALUES(:oe, :oi, :cd, :t, :b, :s)");
		$add->bindparam(":oe",$e);
		$add->bindparam(":oi",$userses);
		$add->bindparam(":cd",$d);
		$add->bindparam(":t",$title);
		$add->bindparam(":b",$body);
		$add->bindparam(":s",$skills);
		$add->execute();
		$add->closeCursor();
         return $add;		
      }

public static function check_useremail($userses) {
    $conn = Database::DB_con();
		  $stmt =$conn->prepare("SELECT * FROM accounts WHERE id='$userses' ");
		  $stmt->execute();
		  $userch=$stmt->fetch(PDO::FETCH_ASSOC);
		  $stmt->closeCursor();
		return $userch;
     }
	
public static function all_user_questions($userses)
	  {
	     $conn = Database::DB_con();
         $sqlq=$conn->prepare("SELECT * FROM questions WHERE ownerid='$userses' ORDER BY createddate DESC ");
	     $sqlq->execute();
		 return $sqlq;
    } 
 
public static function all_questions()
	  {
	     $conn = Database::DB_con();
         $sqla=$conn->prepare("SELECT * FROM questions ORDER BY score DESC ");
	     $sqla->execute();
		 return $sqla;
     } 
// WHERE ownerid='$userses' 
public static function latest_question($userses)
     {
	     $conn = Database::DB_con();
         $sql1=$conn->prepare("SELECT * FROM questions WHERE ownerid='$userses' ORDER BY createddate DESC LIMIT 1 ");
	     $sql1->execute();
		 return $sql1;
   }
public static function view_edit_question($qid)
     {
	 $conn = Database::DB_con();
	$sqledit=$conn->prepare("SELECT * FROM questions WHERE id='$qid' ");
	$sqledit->execute();
	$edit = $sqledit->fetch();
	return $edit;
 }   
 
 public static function view_one_question($qid)
     {
	 $conn = Database::DB_con();;
	$sqlview=$conn->prepare("SELECT * FROM questions WHERE id='$qid' ");
	$sqlview->execute();
	$view = $sqlview->fetch();
	return $view;
 }
 
public static function update_question($qid,$title,$body,$skills,$score)
	{
		 $conn = Database::DB_con();
	$upd = $conn->prepare("UPDATE questions SET title=:t, body=:b, skills=:s,score=:sc WHERE id=:id ");
	$upd->bindparam(":id",$qid);
	$upd->bindparam(":t",$title);
	$upd->bindparam(":b",$body);
	$upd->bindparam(":s",$skills);
	$upd->bindparam(":sc",$score);
	$upd->execute();
   return $upd;
   }
public static function delete_question($qid)
	 {
	   $conn = Database::DB_con();
	 $query = 'DELETE FROM questions
				  WHERE id = :que_id';
    $statement = $conn->prepare($query);
    $statement->bindValue(':que_id', $qid);
    $statement->execute();
    $statement->closeCursor();
  } 
 }
$qclass= new questionData(); 
 
 	/*-------------------------------------------------------------
    	Answers Questions Begins here!
    -------------------------------------------------------------*/
	
	
class answersData{
	public $qid;
	public $score;
	public $answer;
	public $aid;
	public $newscore;
	
	public function getQid(){
        return $this->qid;
      }

    public function setQid($qid){
        $this->uemail = $qid;
      }
	  
	public function getScore(){
        return $this->score;
         }

    public function setScore($score){
        $this->uemail = $score;
       }

    public function getAnswer(){
        return $this->answer;
      }

    public function setAnswer($answer){
        $this->answer = $answer;
      }
	  
	public function getAid(){
        return $this->aid;
      }

    public function setDate($aid){
        $this->aid = $aid;
      }
	  
	 public function getNewscore(){
        return $this->newscore;
      }

    public function setNewscore($newscore){
        $this->newscore = $newscore;
      }
	  
	public static function get_answers($qid)
		  {
			 $conn = Database::DB_con();
			 $quea=$conn->prepare("SELECT * FROM answers WHERE questionid='$qid' ");
			 $quea->execute();
			 return $quea;
	 } 
  public static function new_answer($qid,$answer){
		 $conn = Database::DB_con();			
			$adda = $conn->prepare("INSERT INTO answers(questionid, answer)VALUES(:qid, :qa)");
			$adda->bindparam(":qid",$qid);
			$adda->bindparam(":qa",$answer);
			$adda->execute();
			 return $adda;		
	   }
 public static function get_answers_vote($aid)
		  {
			 $conn = Database::DB_con();
			 $queav=$conn->prepare("SELECT * FROM answers WHERE aid='$aid' ");
			 $queav->execute();
			 $ansscore = $queav->fetch();
			 return $ansscore;
	 } 

public static function update_answer_score($aid,$newscore)
	{
		     $conn = Database::DB_con();
             $updatescore = $conn->prepare("UPDATE answers SET answerscore = '$newscore' WHERE aid='$aid' ");
			  $updatescore->execute();
			 return $updatescore;		
	 
   }	 
}
$aclass= new answersData();

?>