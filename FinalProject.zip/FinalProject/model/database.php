<?php
session_start();
class Database{
	private static $DB_host = 'mysql:host=localhost;dbname=yz746';
	private static $DB_user = "root";
	private static $DB_pass = "";
	//private static $DB_name = "yz746";
	
    private static $db_con;
	
   private function __construct() {}

    public static function DB_con () {
        if (!isset(self::$db_con)) {
            try {
                self::$db_con = new PDO(self::$DB_host,self::$DB_user,self::$DB_pass);
            } catch (PDOException $e) {
                 echo $e->getMessage();
                exit();
              }
           }
        return self::$db_con;
    }
  }
?>